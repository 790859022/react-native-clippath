package com.rtnclippath;

import android.graphics.Color;

import androidx.annotation.Nullable;

import com.facebook.react.module.annotations.ReactModule;
import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.ViewManagerDelegate;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.facebook.react.viewmanagers.RTNClipPathViewManagerDelegate;
import com.facebook.react.viewmanagers.RTNClipPathViewManagerInterface;

@ReactModule(name = RTNClipPathViewManager.NAME)
public class RTNClipPathViewManager extends SimpleViewManager<RTNClipPathView> implements RTNClipPathViewManagerInterface<RTNClipPathView> {

  public static final String NAME = "RTNClipPathView";

  private final ViewManagerDelegate<RTNClipPathView> mDelegate;

  public RTNClipPathViewManager() {
    mDelegate = new RTNClipPathViewManagerDelegate(this);
  }

  @Nullable
  @Override
  protected ViewManagerDelegate<RTNClipPathView> getDelegate() {
    return mDelegate;
  }

  @Override
  public String getName() {
    return NAME;
  }

  @Override
  public RTNClipPathView createViewInstance(ThemedReactContext context) {
    return new RTNClipPathView(context);
  }

  @Override
  @ReactProp(name = "color")
  public void setColor(RTNClipPathView view, String color) {
    view.setBackgroundColor(Color.parseColor(color));
  }
}
