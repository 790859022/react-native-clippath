package com.rtnclippath;

import androidx.annotation.Nullable;

import android.content.Context;
import android.util.AttributeSet;

import android.view.View;

public class RTNClipPathView extends View {

  public RTNClipPathView(Context context) {
    super(context);
  }

  public RTNClipPathView(Context context, @Nullable AttributeSet attrs) {
    super(context, attrs);
  }

  public RTNClipPathView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
  }

}
