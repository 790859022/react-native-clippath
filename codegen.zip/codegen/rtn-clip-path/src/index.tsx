export { default as RTNClipPathView } from './RTNClipPathViewNativeComponent';
export * from './RTNClipPathViewNativeComponent';
