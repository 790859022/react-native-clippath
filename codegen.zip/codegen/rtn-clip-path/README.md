# rtn-clip-path

svg clip path

## Installation

```sh
npm install rtn-clip-path
```

## Usage

```js
import { RTNClipPathView } from "rtn-clip-path";

// ...

<RTNClipPathView color="tomato" />
```

## Contributing

See the [contributing guide](CONTRIBUTING.md) to learn how to contribute to the repository and the development workflow.

## License

MIT

---

Made with [create-react-native-library](https://github.com/callstack/react-native-builder-bob)
